========================
Benchmarks
========================

.. mdinclude:: ../BENCHMARKS.md